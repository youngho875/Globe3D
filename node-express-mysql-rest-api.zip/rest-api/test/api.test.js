const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { once } = require('node:events');
const createApp = require('../src/app');
const key = 'test-api-key-with-at-least-32-characters';
let server, base, rows = [], seq = 0, dbUp = true;
const model = {
  async find(id) { return rows.find(u => u.id === id) || null; },
  async list({ limit, offset }) { return { rows: rows.slice(offset, offset + limit), total: rows.length }; },
  async create(data) { if (rows.some(u => u.email === data.email)) throw Object.assign(new Error('duplicate'), { code: 'ER_DUP_ENTRY' }); const user = { id: ++seq, ...data }; rows.push(user); return user; },
  async update(id, data) { const user = await this.find(id); if (!user) return null; Object.assign(user, data); return user; },
  async remove(id) { const index = rows.findIndex(u => u.id === id); if (index < 0) return false; rows.splice(index, 1); return true; }
};
before(async () => {
  server = createApp({ model, apiKey: key, health: async () => { if (!dbUp) throw Error('down'); }, logger: { error() {} } }).listen(0, '127.0.0.1');
  await once(server, 'listening'); base = `http://127.0.0.1:${server.address().port}`;
});
after(() => new Promise(resolve => server.close(resolve)));
async function request(path, method = 'GET', body, apiKey = key) {
  return fetch(base + path, { method, headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey }, body: body === undefined ? undefined : JSON.stringify(body) });
}
test('CRUD, PUT/PATCH 구분, pagination, 삭제 후 404', async () => {
  const created = await request('/api/users', 'POST', { name: ' 홍길동 ', email: 'Hong@Example.com', age: 0 });
  assert.equal(created.status, 201); const user = (await created.json()).data;
  assert.equal(user.name, '홍길동'); assert.equal(user.email, 'hong@example.com'); assert.equal(created.headers.get('location'), `/api/users/${user.id}`);
  assert.equal((await request(`/api/users/${user.id}`)).status, 200);
  const list = await (await request('/api/users?page=1&limit=1')).json(); assert.equal(list.pagination.total, 1);
  assert.equal((await request(`/api/users/${user.id}`, 'PUT', { age: 31 })).status, 400);
  assert.equal((await request(`/api/users/${user.id}`, 'PUT', { name: '김철수', email: 'kim@example.com', age: 31 })).status, 200);
  const patch = await request(`/api/users/${user.id}`, 'PATCH', { age: 32 }); assert.equal((await patch.json()).data.name, '김철수');
  assert.equal((await request(`/api/users/${user.id}`, 'DELETE')).status, 204);
  assert.equal((await request(`/api/users/${user.id}`)).status, 404);
  assert.equal((await request(`/api/users/${user.id}`, 'PATCH', { age: 1 })).status, 404);
});
test('인증, ID/본문/query 검증', async () => {
  assert.equal((await request('/api/users', 'GET', undefined, 'wrong')).status, 401);
  for (const path of ['/api/users/1abc', '/api/users/0', '/api/users?page=0', '/api/users?limit=101', '/api/users?page=1&page=2', '/api/users?unknown=1']) assert.equal((await request(path)).status, 400);
  for (const body of [null, [], {}, { name: 'A', email: 'bad', age: 1 }, { name: 'A', email: 'a@b.com', age: '20' }, { name: 'A', email: 'a@b.com', age: 151 }, { name: 'A', email: 'a@b.com', age: 1, role: 'admin' }]) assert.equal((await request('/api/users', 'POST', body)).status, 400);
});
test('중복 이메일 409, 잘못된 JSON 400, 과대 요청 413', async () => {
  const body = { name: 'A', email: 'duplicate@example.com', age: 20 };
  assert.equal((await request('/api/users', 'POST', body)).status, 201);
  const duplicate = await request('/api/users', 'POST', body); assert.equal(duplicate.status, 409); assert.equal((await duplicate.json()).error.code, 'EMAIL_CONFLICT');
  const invalid = await fetch(base + '/api/users', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-API-Key': key }, body: '{' }); assert.equal(invalid.status, 400);
  assert.equal((await request('/api/users', 'POST', { ...body, name: 'x'.repeat(110000) })).status, 413);
});
test('health readiness와 예상치 못한 DB 오류 정보 비노출', async () => {
  assert.equal((await request('/health/live')).status, 200);
  dbUp = false; assert.equal((await request('/health/ready')).status, 503); dbUp = true;
  const original = model.list; model.list = async () => { throw new Error('secret password SQL detail'); };
  try {
    const response = await request('/api/users'); assert.equal(response.status, 500); const text = await response.text(); assert.ok(!text.includes('secret')); assert.ok(!text.includes('SQL detail'));
  } finally { model.list = original; }
});
