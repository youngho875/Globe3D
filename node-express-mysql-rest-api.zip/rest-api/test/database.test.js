// 전용 테스트 DB + .env 설정 후 npm run test:db
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { randomUUID } = require('node:crypto');
test('실제 MySQL CRUD, 중복 제약, rollback, 동일 값 update, pagination', async () => {
  const pool = require('../src/config/database');
  const model = require('../src/models/userModel')(pool);
  let id;
  try {
    const email = `${randomUUID()}@example.com`;
    const user = await model.create({ name: 'DB 테스트', email, age: 20 }); id = user.id;
    assert.equal((await model.find(id)).email, email);
    await assert.rejects(model.create({ name: '중복', email, age: 21 }), { code: 'ER_DUP_ENTRY' });
    assert.equal((await model.update(id, { age: 20 })).id, id);
    assert.equal((await model.update(id, { age: 22 })).age, 22);
    const list = await model.list({ limit: 10, offset: 0 }); assert.ok(list.total >= 1);
    assert.equal(await model.remove(id), true); assert.equal(await model.find(id), null);
    assert.equal(await model.update(id, { age: 23 }), null); assert.equal(await model.remove(id), false);
  } finally { if (id) await model.remove(id).catch(() => {}); await pool.end(); }
});
