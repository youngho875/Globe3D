const config = require('./src/config/env');
const pool = require('./src/config/database');
const app = require('./src/app')({
  model: require('./src/models/userModel')(pool), apiKey: config.apiKey, origins: config.origins,
  health: () => pool.query('SELECT 1')
});
let server;
let stopping = false;
async function shutdown(exitCode = 0) {
  if (stopping) return;
  stopping = true;
  const timer = setTimeout(() => process.exit(1), 10000);
  timer.unref();
  try {
    if (server) await new Promise(resolve => server.close(resolve));
    await pool.end();
    clearTimeout(timer);
    process.exitCode = exitCode;
  } catch { process.exit(1); }
}
async function start() {
  try {
    await pool.query('SELECT id FROM users LIMIT 1');
    server = app.listen(config.port, config.host, () => console.log(`REST API: http://${config.host}:${config.port}`));
    server.on('error', error => { console.error('서버 시작 실패:', error.code); void shutdown(1); });
  } catch (error) { console.error('DB 연결/스키마 확인 실패:', error.code || 'UNKNOWN'); await shutdown(1); }
}
process.on('SIGINT', () => void shutdown());
process.on('SIGTERM', () => void shutdown());
void start();
