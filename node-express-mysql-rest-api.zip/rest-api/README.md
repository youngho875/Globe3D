# Node.js + Express + MySQL REST API

사용자 CRUD 전체 프로젝트. CommonJS, Express 5, mysql2 Promise 연결 풀을 사용합니다.

## 준비

- Node.js 22 이상, npm
- MySQL 8.0.16 이상 (CHECK 제약 지원), 8.4 사용 가능
- Docker 없이 로컬/원격 MySQL에서 실행 가능

## 1. 패키지 설치

압축 해제 후 `rest-api` 폴더에서:

```bash
npm ci
```

## 2. MySQL 초기화

MySQL 관리자 계정으로 접속합니다. 비밀번호는 명령행에 직접 넣지 마세요.

```bash
mysql -u root -p
```

MySQL 콘솔에서 실제 파일 위치에 맞게 실행합니다. Windows 경로는 `/`를 사용합니다.

```sql
SOURCE /absolute/path/rest-api/sql/001_init.sql;
```

`sql/002_app_user.sql.example`을 복사하고 비밀번호와 접속 호스트를 변경한 다음 실행합니다.

```sql
SOURCE /absolute/path/rest-api/sql/002_app_user.sql;
```

기존 사용자의 비밀번호는 CREATE USER IF NOT EXISTS로 변경되지 않습니다. 필요하면 관리자가 ALTER USER를 실행하세요. 앱 계정에는 해당 DB의 CRUD 권한만 부여합니다.

## 3. 환경변수 설정

macOS/Linux:

```bash
cp .env.example .env
```

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

`.env`에서 DB 접속 정보와 API_KEY를 변경합니다. 아래 명령으로 API 키를 생성할 수 있습니다.

```bash
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

키는 `.env`에만 보관하세요. 예시 키를 그대로 사용하면 시작을 거부합니다.

```dotenv
HOST=127.0.0.1
PORT=3000
API_KEY=생성한_64자리_키
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=rest_api
DB_USER=rest_api_app
DB_PASSWORD=SQL에서_설정한_비밀번호
DB_POOL_SIZE=10
CORS_ORIGINS=http://localhost:8080
```

## 4. 실행

```bash
npm start
```

파일 변경 자동 반영:

```bash
npm run dev
```

시작 시 DB 연결과 users 테이블을 확인합니다. HOST 기본값은 localhost입니다. 다른 PC에서 접속하려면 HOST=0.0.0.0으로 변경하고 서버 방화벽에 API 포트를 허용하세요.

## API

`/api/*` 요청에는 `X-API-Key` 헤더가 필요합니다. 브라우저 주소창만으로는 인증 헤더를 보낼 수 없으므로 curl, Postman, fetch 등을 사용하세요.

| Method | URL | 기능 |
|---|---|---|
| GET | /api/users?page=1&limit=20 | 목록, 페이지 조회 |
| GET | /api/users/:id | 단일 조회 |
| POST | /api/users | 추가 |
| PUT | /api/users/:id | name/email/age 전체 수정 |
| PATCH | /api/users/:id | 전달 필드만 수정 |
| DELETE | /api/users/:id | 삭제, 204 본문 없음 |
| GET | /health/live | 프로세스 상태 |
| GET | /health/ready | DB 준비 상태, 장애 시 503 |

사용자 필드: name(1~100자), email(254자 이내, 중복 불가), age(정수 0~150).
이메일은 소문자로 정규화합니다. 알 수 없는 필드는 400으로 거절합니다.
페이지 기본값 1, 크기 기본값 20, 최대 크기 100. ID는 MySQL AUTO_INCREMENT로 생성합니다.
created_at/updated_at은 UTC 문자열입니다.

## 요청 예시

macOS/Linux에서 실제 키를 환경변수에 설정한 뒤:

```bash
export API_KEY='실제_API_키'
curl http://localhost:3000/health/ready
curl 'http://localhost:3000/api/users?page=1&limit=20' -H "X-API-Key: $API_KEY"
curl -X POST http://localhost:3000/api/users \
  -H "X-API-Key: $API_KEY" -H 'Content-Type: application/json' \
  -d '{"name":"홍길동","email":"hong@example.com","age":30}'
```

Windows PowerShell:

```powershell
$apiKey = '실제_API_키'
$headers = @{ 'X-API-Key' = $apiKey }
$body = @{ name='홍길동'; email='hong@example.com'; age=30 } | ConvertTo-Json
$created = Invoke-RestMethod -Method Post -Uri 'http://localhost:3000/api/users' -Headers $headers -ContentType 'application/json; charset=utf-8' -Body ([System.Text.Encoding]::UTF8.GetBytes($body))
$userId = $created.data.id
Invoke-RestMethod -Uri "http://localhost:3000/api/users/$userId" -Headers $headers
```

VS Code REST Client 형식의 `examples/requests.http`도 포함했습니다. 키와 생성된 ID를 변경해 사용하세요.

추가 성공 응답 (id와 시각은 예시):

```json
{"success":true,"data":{"id":1,"name":"홍길동","email":"hong@example.com","age":30,"created_at":"2026-10-01 01:00:00.000","updated_at":"2026-10-01 01:00:00.000"}}
```

상태 코드: 200 조회/수정, 201 생성, 204 삭제, 400 입력/JSON 오류, 401 인증 실패, 404 없음, 409 중복 이메일, 413 본문 초과, 500 서버 오류.

## 프로젝트 구성

| 파일/폴더 | 역할 |
|---|---|
| server.js | 시작, DB 확인, 정상 종료 |
| src/app.js | 미들웨어, 인증, 오류 응답 |
| src/config | 환경 설정, DB 연결 풀 |
| src/routes | URL과 컨트롤러 연결 |
| src/controllers | 요청 검증 및 응답 |
| src/services | 업무 처리, 사용자 존재 확인 |
| src/models | SQL, 트랜잭션, 행 잠금 |
| src/middleware | 입력 검증 |
| sql | 스키마 및 최소 권한 계정 예시 |
| test | HTTP 테스트 및 실제 DB 테스트 |

## 검증

```bash
npm test
```

HTTP 테스트는 메모리 테스트 대역을 사용하며 실제 DB를 변경하지 않습니다. 별도로 전용 테스트 MySQL DB를 초기화하고 .env를 연결한 뒤:

```bash
npm run test:db
```

DB 테스트는 임의 이메일의 테스트 사용자를 추가/수정/삭제합니다. 운영 DB가 아닌 전용 테스트 DB를 사용하세요.

## 배포 및 폐쇄망

공용 서버에서는 HTTPS 프록시, 요청 제한, 키 교체 정책을 적용하세요. 이 프로젝트의 공유 API 키는 서버 간 접속용입니다. 공개 웹/모바일 클라이언트에 키를 내장하지 마세요. 사용자별 로그인/권한이 필요한 서비스는 별도 인증 체계가 필요합니다. 원격 DB 연결은 신뢰할 수 있는 네트워크 또는 TLS 설정을 사용하세요. DB 비밀번호, 요청 본문, SQL 오류 상세는 응답/서버 로그에 출력하지 않습니다.

폐쇄망에서는 인터넷 PC에서 동일 Node.js 환경으로 npm ci 후 프로젝트와 node_modules를 함께 압축하여 반입하면 npm 설치 없이 npm start가 가능합니다. OS/CPU와 Node.js 버전을 맞추고 대상 환경에서 확인하세요. 더 재현 가능한 방식은 npm 캐시를 함께 반입한 뒤 npm ci --offline로 설치하는 것입니다. 캐시에 모든 패키지가 있어야 합니다. 이 소스 ZIP에는 node_modules가 포함되지 않습니다.

## 참고 문서

- https://expressjs.com/en/5x/guide/error-handling/
- https://sidorares.github.io/node-mysql2/docs/examples/connections/create-pool
- https://sidorares.github.io/node-mysql2/docs/examples/queries/prepared-statements/select
