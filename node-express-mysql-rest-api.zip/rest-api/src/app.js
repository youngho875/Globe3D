const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const { createHash, timingSafeEqual, randomUUID } = require('node:crypto');
const ApiError = require('./utils/ApiError');
module.exports = function createApp({ model, health, apiKey, origins = [], logger = console }) {
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet());
  app.use((req, res, next) => { req.requestId = randomUUID(); res.set('X-Request-ID', req.requestId); next(); });
  if (origins.length) app.use(cors({ origin: origins, methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], allowedHeaders: ['Content-Type', 'X-API-Key'] }));
  app.get('/health/live', (req, res) => res.json({ success: true, status: 'ok' }));
  app.get('/health/ready', async (req, res) => {
    try { await health(); res.json({ success: true, status: 'ready' }); }
    catch { res.status(503).json({ success: false, status: 'unavailable' }); }
  });
  const hash = s => createHash('sha256').update(s).digest();
  const expected = hash(apiKey);
  app.use('/api', (req, res, next) => {
    const key = req.get('X-API-Key');
    if (!key || !timingSafeEqual(hash(key), expected)) return next(new ApiError(401, 'UNAUTHORIZED', 'API 키가 필요하거나 올바르지 않습니다.'));
    next();
  });
  app.use(express.json({ limit: '100kb' }));
  app.use('/api/users', require('./routes/users')(require('./controllers/userController')(require('./services/userService')(model))));
  app.use((req, res, next) => next(new ApiError(404, 'NOT_FOUND', '존재하지 않는 API입니다.')));
  app.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    let status = error.status || 500, code = error.code || 'INTERNAL_ERROR', message = error.message;
    if (error.code === 'ER_DUP_ENTRY') { status = 409; code = 'EMAIL_CONFLICT'; message = '이미 등록된 이메일입니다.'; }
    else if (error.type === 'entity.parse.failed') { status = 400; code = 'INVALID_JSON'; message = 'JSON 형식이 잘못되었습니다.'; }
    else if (error.type === 'entity.too.large') { status = 413; code = 'PAYLOAD_TOO_LARGE'; message = '요청 본문이 너무 큽니다.'; }
    else if (!(error instanceof ApiError)) { status = status >= 400 && status < 500 ? status : 500; code = status === 500 ? 'INTERNAL_ERROR' : 'BAD_REQUEST'; message = status === 500 ? '서버 내부 오류가 발생했습니다.' : '요청을 처리할 수 없습니다.'; }
    if (status >= 500) logger.error({ requestId: req.requestId, code: error.code || 'INTERNAL_ERROR' });
    res.status(status).json({ success: false, error: { code, message, requestId: req.requestId } });
  });
  return app;
};
