const validate = require('../middleware/validation');
module.exports = service => ({
  list: async (req, res) => {
    const options = validate.pagination(req.query);
    const { rows, total } = await service.list(options);
    res.json({ success: true, data: rows, pagination: { page: options.page, limit: options.limit, total, totalPages: Math.ceil(total / options.limit) } });
  },
  get: async (req, res) => res.json({ success: true, data: await service.get(validate.id(req.params.id)) }),
  create: async (req, res) => {
    const user = await service.create(validate.body(req.body));
    res.location(`/api/users/${user.id}`).status(201).json({ success: true, data: user });
  },
  replace: async (req, res) => res.json({ success: true, data: await service.update(validate.id(req.params.id), validate.body(req.body)) }),
  patch: async (req, res) => res.json({ success: true, data: await service.update(validate.id(req.params.id), validate.body(req.body, true)) }),
  remove: async (req, res) => { await service.remove(validate.id(req.params.id)); res.status(204).end(); }
});
