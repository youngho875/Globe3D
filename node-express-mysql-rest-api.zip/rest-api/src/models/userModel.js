const columns = 'id, name, email, age, created_at, updated_at';
module.exports = function userModel(pool) {
  async function transaction(work) {
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      const result = await work(conn);
      await conn.commit();
      return result;
    } catch (error) {
      try { await conn.rollback(); } catch { /* 원래 오류 보존 */ }
      throw error;
    } finally { conn.release(); }
  }
  async function find(id, conn = pool, lock = false) {
    const [rows] = await conn.execute(`SELECT ${columns} FROM users WHERE id = ?${lock ? ' FOR UPDATE' : ''}`, [id]);
    return rows[0] || null;
  }
  return {
    find,
    async list({ limit, offset }) {
      return transaction(async conn => {
        const [[count]] = await conn.execute('SELECT COUNT(*) AS total FROM users');
        // query도 값은 placeholder로 escape; 필드/정렬은 사용자 입력을 사용하지 않음
        const [rows] = await conn.query(`SELECT ${columns} FROM users ORDER BY id LIMIT ? OFFSET ?`, [limit, offset]);
        return { rows, total: Number(count.total) };
      });
    },
    async create(data) {
      return transaction(async conn => {
        const [result] = await conn.execute('INSERT INTO users (name, email, age) VALUES (?, ?, ?)', [data.name, data.email, data.age]);
        return find(result.insertId, conn);
      });
    },
    async update(id, data) {
      return transaction(async conn => {
        const current = await find(id, conn, true);
        if (!current) return null;
        const next = { ...current, ...data };
        await conn.execute('UPDATE users SET name = ?, email = ?, age = ? WHERE id = ?', [next.name, next.email, next.age, id]);
        return find(id, conn);
      });
    },
    async remove(id) {
      const [result] = await pool.execute('DELETE FROM users WHERE id = ?', [id]);
      return result.affectedRows > 0;
    }
  };
};
