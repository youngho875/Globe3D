const path = require('node:path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env'), quiet: true });
function integer(name, fallback, max = 65535) {
  const value = process.env[name] || String(fallback);
  if (!/^\d+$/.test(value) || Number(value) < 1 || Number(value) > max) throw new Error(`${name} 설정값이 잘못되었습니다.`);
  return Number(value);
}
function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`${name} 설정이 필요합니다.`);
  return value;
}
const apiKey = required('API_KEY');
if (apiKey.length < 32 || apiKey.startsWith('replace-')) throw new Error('API_KEY를 32자 이상의 새 비밀키로 변경하세요.');
module.exports = {
  host: process.env.HOST || '127.0.0.1', port: integer('PORT', 3000), apiKey,
  origins: (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean),
  database: { host: process.env.DB_HOST || '127.0.0.1', port: integer('DB_PORT', 3306),
    database: required('DB_NAME'), user: required('DB_USER'), password: required('DB_PASSWORD'),
    waitForConnections: true, connectionLimit: integer('DB_POOL_SIZE', 10, 100),
    queueLimit: 100, connectTimeout: 10000, charset: 'utf8mb4', timezone: 'Z', dateStrings: true }
};
