const mysql = require('mysql2/promise');
const config = require('./env');
const pool = mysql.createPool(config.database);
// 각 새 연결의 MySQL 세션도 UTC로 고정합니다.
pool.on('connection', connection => {
  connection.query("SET time_zone = '+00:00'", error => { if (error) connection.destroy(); });
});
module.exports = pool;
