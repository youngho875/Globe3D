const ApiError = require('../utils/ApiError');
const bad = message => { throw new ApiError(400, 'VALIDATION_ERROR', message); };
function id(value) {
  if (!/^[1-9]\d*$/.test(value) || !Number.isSafeInteger(Number(value)) || Number(value) > 4294967295) bad('id는 양의 정수여야 합니다.');
  return Number(value);
}
function body(value, partial = false) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) bad('JSON 객체가 필요합니다.');
  const keys = Object.keys(value);
  if (keys.some(k => !['name', 'email', 'age'].includes(k))) bad('허용 필드: name, email, age');
  if (!keys.length) bad('수정할 필드가 필요합니다.');
  const result = {};
  for (const key of ['name', 'email', 'age']) {
    if (!Object.hasOwn(value, key)) { if (!partial) bad(`${key}가 필요합니다.`); continue; }
    const v = value[key];
    if (key === 'name') {
      if (typeof v !== 'string' || !v.trim() || [...v.trim()].length > 100) bad('name은 1~100자 문자열이어야 합니다.');
      result.name = v.trim();
    } else if (key === 'email') {
      if (typeof v !== 'string' || v.trim().length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim())) bad('email 형식이 잘못되었습니다.');
      result.email = v.trim().toLowerCase();
    } else {
      if (!Number.isInteger(v) || v < 0 || v > 150) bad('age는 0~150 사이의 정수여야 합니다.');
      result.age = v;
    }
  }
  return result;
}
function pagination(query) {
  if (Object.keys(query).some(k => !['page', 'limit'].includes(k))) bad('허용 조회 파라미터: page, limit');
  const parse = (v, fallback, max) => {
    if (v === undefined) return fallback;
    if (typeof v !== 'string' || !/^[1-9]\d*$/.test(v) || !Number.isSafeInteger(Number(v)) || Number(v) > max) bad('page 또는 limit 값이 잘못되었습니다.');
    return Number(v);
  };
  const page = parse(query.page, 1, 1000000), limit = parse(query.limit, 20, 100);
  return { page, limit, offset: (page - 1) * limit };
}
module.exports = { id, body, pagination };
