const express = require('express');
module.exports = controller => {
  const router = express.Router();
  router.get('/', controller.list);
  router.get('/:id', controller.get);
  router.post('/', controller.create);
  router.put('/:id', controller.replace);
  router.patch('/:id', controller.patch);
  router.delete('/:id', controller.remove);
  return router;
};
