const ApiError = require('../utils/ApiError');
module.exports = model => {
  const ensure = user => { if (!user) throw new ApiError(404, 'USER_NOT_FOUND', '사용자를 찾을 수 없습니다.'); return user; };
  return {
    list: options => model.list(options),
    get: async id => ensure(await model.find(id)),
    create: data => model.create(data),
    update: async (id, data) => ensure(await model.update(id, data)),
    remove: async id => { if (!await model.remove(id)) ensure(null); }
  };
};
