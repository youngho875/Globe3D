-- MySQL 관리자 계정으로 실행하세요. 기존 데이터는 삭제하지 않습니다.
CREATE DATABASE IF NOT EXISTS rest_api CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rest_api;
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(254) NOT NULL,
  age TINYINT UNSIGNED NOT NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  CONSTRAINT chk_users_age CHECK (age <= 150)
) ENGINE=InnoDB;
-- 모든 timestamp는 UTC 저장; DB 세션 timezone은 mysql2의 timezone과 별도임
