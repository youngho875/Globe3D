//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Test_WarSym.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_Test_WarSymTYPE             129
#define IDR_MENU_POP                    144
#define IDD_MAKE_IMG_ALL                149
#define IDR_MENU_POP_DEBUG              151
#define IDR_MENU1                       152
#define IDR_MENU_TGLABEL                152
#define IDC_ED_OUTPATH                  1095
#define IDC_CB_FILE_EXT                 1098
#define IDC_ED_POSTFIX                  1100
#define IDC_CHK_TACSYM                  1101
#define IDC_CHK_TACPOINT                1102
#define IDC_CHK_TACGRPX                 1103
#define ID_TGLABEL_START                10001
#define ID_TGLABEL_END                  10100
#define ID_WS_SELECT                    32771
#define ID_DRAWMODE_COLOR               32773
#define ID_DRAWMODE_FILL_FRAME          32774
#define ID_DRAWMODE_BG                  32775
#define ID_DRAWMODE_SHOW_FRAME          32776
#define ID_DRAWMODE_SHOW_ICON           32777
#define ID_LUMINO_DARK                  32778
#define ID_LUMINO_MEDIUM                32779
#define ID_LUMINO_LIGHT                 32780
#define ID_LUMINO_CUSTOM                32784
#define ID_WS_GENIMG                    32787
#define ID_TEST_SPEED                   32804
#define ID_TEST_CLEAR                   32806
#define ID_EDIT_DELETE                  32808
#define ID_EDIT_PROPERTY                32810
#define ID_TOOL_ENCODING                32811
#define ID_TEST_CACHE_SYMIMG            32815
#define ID_WS_COPY                      32816
#define ID_EDIT_REFRESH_MODE            32817
#define ID_EDIT_INVERSE_MODE            32818
#define ID_USE_COMMON_LANG              32821
#define ID_DEBUG_PATTERN_LINE           32822
#define ID_DEBUG_MEM_LEAK               32823
#define ID_EDIT_PAIRING_ADD             32824
#define ID_EDIT_PAIRING_RESET           32825
#define ID_Menu                         32826

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32828
#define _APS_NEXT_CONTROL_VALUE         1102
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
